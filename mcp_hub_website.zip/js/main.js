// Main JavaScript for MCP Hub

document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInput = document.querySelector('.search-box input');
    const searchButton = document.querySelector('.search-box button');
    
    if (searchInput && searchButton) {
        searchButton.addEventListener('click', function() {
            performSearch(searchInput.value);
        });
        
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performSearch(searchInput.value);
            }
        });
    }
    
    // Function to handle search
    function performSearch(query) {
        if (query.trim() !== '') {
            window.location.href = `directory.html?search=${encodeURIComponent(query)}`;
        }
    }
    
    // Mobile navigation toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('nav ul');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('show');
        });
    }
    
    // Filter functionality for directory page
    const filterButtons = document.querySelectorAll('.filter-button');
    
    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const filter = this.dataset.filter;
                filterServers(filter);
            });
        });
    }
    
    // Function to filter servers
    function filterServers(filter) {
        const serverCards = document.querySelectorAll('.server-card');
        
        if (filter === 'all') {
            serverCards.forEach(card => {
                card.style.display = 'block';
            });
        } else {
            serverCards.forEach(card => {
                if (card.classList.contains(filter)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    }
    
    // Category filter functionality
    const categorySelect = document.getElementById('category-filter');
    
    if (categorySelect) {
        categorySelect.addEventListener('change', function() {
            const category = this.value;
            filterByCategory(category);
        });
    }
    
    // Function to filter by category
    function filterByCategory(category) {
        const serverCards = document.querySelectorAll('.server-card');
        
        if (category === 'all') {
            serverCards.forEach(card => {
                card.style.display = 'block';
            });
        } else {
            serverCards.forEach(card => {
                const serverCategory = card.dataset.category;
                if (serverCategory === category) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    }
    
    // SDK filter functionality
    const sdkSelect = document.getElementById('sdk-filter');
    
    if (sdkSelect) {
        sdkSelect.addEventListener('change', function() {
            const sdk = this.value;
            filterBySDK(sdk);
        });
    }
    
    // Function to filter by SDK
    function filterBySDK(sdk) {
        const serverCards = document.querySelectorAll('.server-card');
        
        if (sdk === 'all') {
            serverCards.forEach(card => {
                card.style.display = 'block';
            });
        } else {
            serverCards.forEach(card => {
                const serverSDK = card.dataset.sdk;
                if (serverSDK === sdk) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    }
    
    // Initialize repository data
    initRepositoryData();
});

// Function to initialize repository data
function initRepositoryData() {
    // This function will be expanded in the repository collection system
    // It will fetch and display repository data from GitHub
    console.log('Repository data initialization');
    
    // For now, we'll use placeholder data
    // This will be replaced with actual API calls in the repository collection system
}

// Function to fetch repository data from GitHub
function fetchRepositoryData(owner, repo) {
    // This will be implemented in the repository collection system
    // It will use the GitHub API to fetch repository information
    console.log(`Fetching data for ${owner}/${repo}`);
}

// Function to display repository details
function displayRepositoryDetails(repoData) {
    // This will be implemented in the repository collection system
    // It will update the UI with repository information
    console.log('Displaying repository details');
}

// Function to handle pagination
function handlePagination(page) {
    // This will be implemented for the directory page
    // It will handle pagination of repository listings
    console.log(`Navigating to page ${page}`);
}

// Function to sort repositories
function sortRepositories(sortBy) {
    // This will be implemented for the directory page
    // It will sort repositories by different criteria
    console.log(`Sorting by ${sortBy}`);
}
