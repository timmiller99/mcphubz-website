// Server Details JavaScript for MCP Hub

document.addEventListener('DOMContentLoaded', function() {
    // Get server ID from URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const serverId = urlParams.get('id');
    
    if (serverId) {
        loadServerDetails(serverId);
    } else {
        showError('No server ID specified');
    }
    
    // Initialize copy to clipboard functionality
    initCopyToClipboard();
});

// Function to load server details
async function loadServerDetails(serverId) {
    try {
        // First check if we have repositories in localStorage
        let repositories = [];
        const repoData = localStorage.getItem('mcpRepositories');
        
        if (repoData) {
            repositories = JSON.parse(repoData);
        } else {
            // If no data in localStorage, try to fetch from GitHub
            await collectRepositories();
            const updatedRepoData = localStorage.getItem('mcpRepositories');
            if (updatedRepoData) {
                repositories = JSON.parse(updatedRepoData);
            }
        }
        
        // Find the repository by ID (fullName)
        const repository = repositories.find(repo => repo.fullName === serverId);
        
        if (repository) {
            displayServerDetails(repository);
            fetchAdditionalDetails(repository);
            loadRelatedServers(repository, repositories);
        } else {
            // If not found in our data, try to fetch directly from GitHub
            const [owner, name] = serverId.split('/');
            fetchRepositoryDetails(owner, name)
                .then(repo => {
                    displayServerDetails(repo);
                    fetchAdditionalDetails(repo);
                })
                .catch(error => {
                    showError(`Repository not found: ${serverId}`);
                    console.error(error);
                });
        }
    } catch (error) {
        showError('Error loading server details');
        console.error(error);
    }
}

// Function to display server details
function displayServerDetails(repository) {
    // Update page title
    document.title = `${repository.name} - MCP Hub`;
    
    // Update server name and badges
    document.getElementById('server-name').textContent = repository.name;
    
    const statusBadge = document.getElementById('server-status');
    statusBadge.textContent = isOfficialRepo(repository) ? 'Official' : 'Community';
    statusBadge.className = `badge ${isOfficialRepo(repository) ? 'official' : 'community'}`;
    
    // Set category badge
    const categoryBadge = document.getElementById('server-category');
    const category = guessCategory(repository);
    categoryBadge.textContent = category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ');
    
    // Set SDK badge
    const sdkBadge = document.getElementById('server-sdk');
    const sdk = getSDKForRepo(repository);
    sdkBadge.textContent = sdk.charAt(0).toUpperCase() + sdk.slice(1);
    
    // Update stats
    document.getElementById('server-stars').textContent = repository.stars || 0;
    document.getElementById('server-forks').textContent = repository.forks || 0;
    document.getElementById('server-updated').textContent = formatDate(repository.updatedAt);
    
    // Update description
    document.getElementById('server-description').textContent = repository.description || 'No description available.';
    
    // Update links
    document.getElementById('github-link').href = repository.url;
    document.getElementById('issues-link').href = `${repository.url}/issues`;
    document.getElementById('docs-link').href = `${repository.url}#readme`;
    
    // Update installation code
    updateInstallationCode(repository);
    
    // Update configuration code
    updateConfigurationCode(repository);
    
    // Update usage code
    updateUsageCode(repository);
}

// Function to fetch additional details from GitHub
async function fetchAdditionalDetails(repository) {
    try {
        // Fetch README content
        const readmeResponse = await fetch(
            `https://api.github.com/repos/${repository.fullName}/readme`,
            {
                headers: {
                    'Accept': 'application/vnd.github.v3+json',
                    'User-Agent': 'MCP-Hub-Collector'
                }
            }
        ).then(res => res.json());
        
        if (readmeResponse.content) {
            // Decode content from base64
            const content = atob(readmeResponse.content);
            
            // Extract capabilities from README
            extractCapabilities(content);
            
            // Update installation and usage examples if available
            extractCodeExamples(content, repository);
        }
        
        // Fetch repository topics
        const topicsResponse = await fetch(
            `https://api.github.com/repos/${repository.fullName}/topics`,
            {
                headers: {
                    'Accept': 'application/vnd.github.mercy-preview+json',
                    'User-Agent': 'MCP-Hub-Collector'
                }
            }
        ).then(res => res.json());
        
        if (topicsResponse.names && topicsResponse.names.length > 0) {
            // Update capabilities with topics
            updateCapabilitiesWithTopics(topicsResponse.names);
        }
    } catch (error) {
        console.error('Error fetching additional details:', error);
    }
}

// Function to extract capabilities from README
function extractCapabilities(readmeContent) {
    const capabilitiesList = document.getElementById('server-capabilities-list');
    if (!capabilitiesList) return;
    
    // Clear existing content
    capabilitiesList.innerHTML = '';
    
    // Look for capability keywords in README
    const capabilities = [];
    
    // Check for resources
    if (readmeContent.includes('resource') || readmeContent.includes('Resource')) {
        capabilities.push('Provides Resources');
    }
    
    // Check for tools
    if (readmeContent.includes('tool') || readmeContent.includes('Tool')) {
        capabilities.push('Provides Tools');
    }
    
    // Check for prompts
    if (readmeContent.includes('prompt') || readmeContent.includes('Prompt')) {
        capabilities.push('Provides Prompts');
    }
    
    // Check for API integration
    if (readmeContent.includes('API') || readmeContent.includes('api')) {
        capabilities.push('API Integration');
    }
    
    // Check for database
    if (readmeContent.includes('database') || readmeContent.includes('Database')) {
        capabilities.push('Database Access');
    }
    
    // Check for file system
    if (readmeContent.includes('file') || readmeContent.includes('File')) {
        capabilities.push('File System Access');
    }
    
    // Check for search
    if (readmeContent.includes('search') || readmeContent.includes('Search')) {
        capabilities.push('Search Functionality');
    }
    
    // Add capabilities to the list
    if (capabilities.length > 0) {
        capabilities.forEach(capability => {
            const li = document.createElement('li');
            li.textContent = capability;
            capabilitiesList.appendChild(li);
        });
    } else {
        // Default capability if none detected
        const li = document.createElement('li');
        li.textContent = 'MCP Server Functionality';
        capabilitiesList.appendChild(li);
    }
}

// Function to update capabilities with repository topics
function updateCapabilitiesWithTopics(topics) {
    const capabilitiesList = document.getElementById('server-capabilities-list');
    if (!capabilitiesList) return;
    
    // Add topics as capabilities
    topics.forEach(topic => {
        // Skip common topics
        if (['mcp', 'server', 'model-context-protocol'].includes(topic)) {
            return;
        }
        
        // Format topic name
        const formattedTopic = topic
            .split('-')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
        
        // Check if this capability is already in the list
        let exists = false;
        for (let i = 0; i < capabilitiesList.children.length; i++) {
            if (capabilitiesList.children[i].textContent.includes(formattedTopic)) {
                exists = true;
                break;
            }
        }
        
        // Add if not exists
        if (!exists) {
            const li = document.createElement('li');
            li.textContent = formattedTopic;
            capabilitiesList.appendChild(li);
        }
    });
}

// Function to extract code examples from README
function extractCodeExamples(readmeContent, repository) {
    // Look for code blocks in README
    const codeBlocks = readmeContent.match(/```(?:typescript|javascript|python|java|kotlin)?\n([\s\S]*?)```/g);
    
    if (codeBlocks && codeBlocks.length > 0) {
        // Find installation example
        const installationBlock = codeBlocks.find(block => 
            block.includes('npm install') || 
            block.includes('pip install') || 
            block.includes('gradle') ||
            block.includes('maven')
        );
        
        if (installationBlock) {
            const installationCode = installationBlock.replace(/```(?:typescript|javascript|python|java|kotlin)?\n/, '').replace(/```$/, '');
            document.getElementById('server-installation-code').textContent = installationCode;
        }
        
        // Find configuration example
        const configBlock = codeBlocks.find(block => 
            block.includes('config') || 
            block.includes('Config') || 
            block.includes('settings') ||
            block.includes('options')
        );
        
        if (configBlock) {
            const configCode = configBlock.replace(/```(?:typescript|javascript|python|java|kotlin)?\n/, '').replace(/```$/, '');
            document.getElementById('server-configuration-code').textContent = configCode;
        }
        
        // Find usage example
        const usageBlock = codeBlocks.find(block => 
            block.includes('import') || 
            block.includes('require') || 
            block.includes('new ') ||
            block.includes('create')
        );
        
        if (usageBlock) {
            const usageCode = usageBlock.replace(/```(?:typescript|javascript|python|java|kotlin)?\n/, '').replace(/```$/, '');
            document.getElementById('server-usage-code').textContent = usageCode;
        }
    }
}

// Function to update installation code
function updateInstallationCode(repository) {
    const installationCode = document.getElementById('server-installation-code');
    const language = repository.language ? repository.language.toLowerCase() : '';
    
    if (language === 'typescript' || language === 'javascript') {
        installationCode.textContent = `npm install @mcp/${repository.name.toLowerCase()}`;
    } else if (language === 'python') {
        installationCode.textContent = `pip install mcp-${repository.name.toLowerCase()}`;
    } else if (language === 'java' || language === 'kotlin') {
        installationCode.textContent = `// Add to your build.gradle
dependencies {
    implementation 'io.modelcontextprotocol:${repository.name.toLowerCase()}:latest'
}`;
    } else {
        installationCode.textContent = `# Installation instructions not available
# Please check the repository README for details`;
    }
}

// Function to update configuration code
function updateConfigurationCode(repository) {
    const configCode = document.getElementById('server-configuration-code');
    const language = repository.language ? repository.language.toLowerCase() : '';
    
    if (language === 'typescript' || language === 'javascript') {
        configCode.textContent = `// Configuration for ${repository.name}
{
  "name": "${repository.name.toLowerCase()}",
  "command": "npx ${repository.name.toLowerCase()}",
  "options": {
    // Add your configuration options here
  }
}`;
    } else if (language === 'python') {
        configCode.textContent = `# Configuration for ${repository.name}
{
  "name": "${repository.name.toLowerCase()}",
  "command": "python -m ${repository.name.toLowerCase()}",
  "options": {
    # Add your configuration options here
  }
}`;
    } else if (language === 'java' || language === 'kotlin') {
        configCode.textContent = `// Configuration for ${repository.name}
{
  "name": "${repository.name.toLowerCase()}",
  "command": "java -jar ${repository.name.toLowerCase()}.jar",
  "options": {
    // Add your configuration options here
  }
}`;
    } else {
        configCode.textContent = `# Configuration for ${repository.name}
# Please check the repository README for specific configuration options`;
    }
}

// Function to update usage code
function updateUsageCode(repository) {
    const usageCode = document.getElementById('server-usage-code');
    const language = repository.language ? repository.language.toLowerCase() : '';
    
    if (language === 'typescript' || language === 'javascript') {
        usageCode.textContent = `// Example usage with Claude Desktop
// 1. Install the server
// 2. Configure in Claude Desktop config file:
{
  "mcpServers": [
    {
      "name": "${repository.name}",
      "command": "npx ${repository.name.toLowerCase()}",
      "options": {}
    }
  ]
}
// 3. Restart Claude Desktop and use the server`;
    } else if (language === 'python') {
        usageCode.textContent = `# Example usage with Claude Desktop
# 1. Install the server
# 2. Configure in Claude Desktop config file:
{
  "mcpServers": [
    {
      "name": "${repository.name}",
      "command": "python -m ${repository.name.toLowerCase()}",
      "options": {}
    }
  ]
}
# 3. Restart Claude Desktop and use the server`;
    } else if (language === 'java' || language === 'kotlin') {
        usageCode.textContent = `// Example usage with Claude Desktop
// 1. Install the server
// 2. Configure in Claude Desktop config file:
{
  "mcpServers": [
    {
      "name": "${repository.name}",
      "command": "java -jar ${repository.name.toLowerCase()}.jar",
      "options": {}
    }
  ]
}
// 3. Restart Claude Desktop and use the server`;
    } else {
        usageCode.textContent = `# Example usage with Claude Desktop
# 1. Install the server
# 2. Configure in Claude Desktop config file
# 3. Restart Claude Desktop and use the server
# Please check the repository README for specific usage instructions`;
    }
}

// Function to load related servers
function loadRelatedServers(repository, repositories) {
    const relatedServersList = document.getElementById('related-servers-list');
    if (!relatedServersList) return;
    
    // Clear existing content
    relatedServersList.innerHTML = '';
    
    // Get category for current repository
    const category = guessCategory(repository);
    
    // Find related repositories (same category, excluding current one)
    const relatedRepos = repositories
        .filter(repo => guessCategory(repo) === category && repo.fullName !== repository.fullName)
        .slice(0, 3);
    
    if (relatedRepos.length > 0) {
        relatedRepos.forEach(repo => {
            const relatedCard = document.createElement('div');
            relatedCard.className = 'related-card';
            
            relatedCard.innerHTML = `
                <h4>${repo.name}</h4>
                <p>${repo.description || 'No description available.'}</p>
                <a href="server.html?id=${encodeURIComponent(repo.fullName)}" class="btn btn-small">View</a>
            `;
            
            relatedServersList.appendChild(relatedCard);
        });
    } else {
        relatedServersList.innerHTML = '<p>No related servers found.</p>';
    }
}

// Function to show error message
function showError(message) {
    const serverContent = document.querySelector('.server-content');
    if (serverContent) {
        serverContent.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <p>${message}</p>
                <a href="directory.html" class="btn">Back to Directory</a>
            </div>
        `;
    }
}

// Function to initialize copy to clipboard functionality
function initCopyToClipboard() {
    window.copyToClipboard = function(elementId) {
        const element = document.getElementById(elementId);
        if (!element) return;
        
        const text = element.textContent;
        navigator.clipboard.writeText(text).then(
            function() {
                // Show success message
                const copyBtn = document.querySelector(`#${elementId} + .copy-btn`);
                if (copyBtn) {
                    const originalHTML = copyBtn.innerHTML;
                    copyBtn.innerHTML = '<i class="fas fa-check"></i>';
                    setTimeout(() => {
                        copyBtn.innerHTML = originalHTML;
                    }, 2000);
                }
            },
            function(err) {
                console.error('Could not copy text: ', err);
            }
        );
    };
}

// Helper function to format date
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 1) {
        return 'Today';
    } else if (diffDays <= 2) {
        return 'Yesterday';
    } else if (diffDays <= 7) {
        return `${diffDays} days ago`;
    } else if (diffDays <= 30) {
        const weeks = Math.floor(diffDays / 7);
        return `${weeks} ${weeks === 1 ? 'week' : 'weeks'} ago`;
    } else if (diffDays <= 365) {
        const months = Math.floor(diffDays / 30);
        return `${months} ${months === 1 ? 'month' : 'months'} ago`;
    } else {
        const years = Math.floor(diffDays / 365);
        return `${years} ${years === 1 ? 'year' : 'years'} ago`;
    }
}

// Helper function to determine if a repository is official
function isOfficialRepo(repo) {
    return repo.owner === 'modelcontextprotocol';
}

// Helper function to guess category for a repository
function guessCategory(repo) {
    const nameAndDesc = (repo.name + ' ' + (repo.description || '')).toLowerCase();
    
    if (nameAndDesc.includes('database') || nameAndDesc.includes('file') || 
        nameAndDesc.includes('storage') || nameAndDesc.includes('drive')) {
        return 'data-access';
    } else if (nameAndDesc.includes('search') || nameAndDesc.includes('find') || 
               nameAndDesc.includes('query')) {
        return 'search';
    } else if (nameAndDesc.includes('content') || nameAndDesc.includes('fetch') || 
               nameAndDesc.includes('scrape') || nameAndDesc.includes('puppeteer')) {
        return 'content-processing';
    } else if (nameAndDesc.includes('github') || nameAndDesc.includes('slack') || 
               nameAndDesc.includes('integration') || nameAndDesc.includes('api')) {
        return 'tool-integration';
    } else if (nameAndDesc.includes('memory') || nameAndDesc.includes('graph') || 
               nameAndDesc.includes('knowledge')) {
        return 'memory-systems';
    } else {
        return 'other';
    }
}

// Helper function to guess SDK for a repository
function getSDKForRepo(repo) {
    const language = repo.language ? repo.language.toLowerCase() : '';
    
    if (language === 'typescript' || language === 'javascript') {
        return 'typescript';
    } else if (language === 'python') {
        return 'python';
    } else if (language === 'java') {
        return 'java';
    } else if (language === 'kotlin') {
        return 'kotlin';
    } else {
        return 'other';
    }
}
